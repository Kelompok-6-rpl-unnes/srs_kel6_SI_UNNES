<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_bahan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->fungsi->restrict();
		$this->load->model('master/m_master_mata_kuliah');
	}

	public function index()
	{
		$this->fungsi->check_previleges('nama_mata_kuliah');
		$data['master_bahan'] = $this->m_master_bahan->getData();
		$this->load->view('master/master_mata_kuliah/v_master_mata_kuliah',$data);
	}

	public function form($param='')
	{
		$content   = "<div id='divsubcontent'></div>";
		$header    = "Form Master Mata Kuliah";
		$subheader = "nama_mata_kuliah";
		$buttons[] = button('jQuery.facebox.close()','Tutup','btn btn-default','data-dismiss="modal"');
		echo $this->fungsi->parse_modal($header,$subheader,$content,$buttons,"");
		if($param=='base'){
			$this->fungsi->run_js('load_silent("master/nama_mata_kuliah/show_addForm/","#divsubcontent")');	
		}else{
			$base_kom=$this->uri->segment(5);
			$this->fungsi->run_js('load_silent("master/nama_mata_kuliah/show_editForm/'.$base_kom.'","#divsubcontent")');	
		}
	}

	public function show_addForm()
	{
		$this->fungsi->check_previleges('nama_mata_kuliah');
		$this->load->library('form_validation');
		$config = array(
				array(
					'field'	=> 'nama_mata_kuliah',
					'label' => 'nama_mata_kuliah',
					'rules' => 'required'
				)
			);
		$this->form_validation->set_rules($config);
		$this->form_validation->set_error_delimiters('<span class="error-span">', '</span>');

		if ($this->form_validation->run() == FALSE)
		{
			$data['status']='';
			$this->load->view('master/nama_mata_kuliah/v_nama_mata_kuliah_add',$data);
		}
		else
		{
			$datapost = get_post_data(array('kode','nama_mata_kuliah','jadwal','jam_belajar','dosen'));
			$this->m_nama_alat->insertData($datapost);
			$this->fungsi->run_js('load_silent("master/nama_mata_kuliah","#content")');
			$this->fungsi->message_box("Data Master Nama Alat sukses disimpan...","success");
			$this->fungsi->catat($datapost,"Menambah Master nama_mata_kuliah dengan data sbb:",true);
		}
	}

	public function show_editForm($id='')
	{
		$this->fungsi->check_previleges('nama_mata_kuliah');
		$this->load->library('form_validation');
		$config = array(
				array(
					'field'	=> 'id',
					'label' => 'wes mbarke',
					'rules' => ''
				),
				array(
					'field'	=> 'nama_mata_kuliah',
					'label' => 'nama_mata_kuliah',
					'rules' => 'required'
				)
			);
		$this->form_validation->set_rules($config);
		$this->form_validation->set_error_delimiters('<span class="error-span">', '</span>');

		if ($this->form_validation->run() == FALSE)
		{
			$data['edit'] = $this->db->get_where('master_nama_mata_kuliah',array('id'=>$id));
			$data['status']='';
			$this->load->view('master/nama_mata_kuliah/v_nama_mata_kuliah_edit',$data);
		}
		else
		{
			$datapost = get_post_data(array('kode','nama_mata_kuliah','jadwal','jam_belajar','dosen'));
			$this->m_nama_alat->updateData($datapost);
			$this->fungsi->run_js('load_silent("master/nama_mata_kuliah","#content")');
			$this->fungsi->message_box("Data Master Nama Mata Kuliah sukses diperbarui...","success");
			$this->fungsi->catat($datapost,"Mengedit Master nama_mata_kuliah dengan data sbb:",true);
		}
	}
}

/* End of file nama_alat.php */
/* Location: ./application/controllers/master/nama_alat.php */